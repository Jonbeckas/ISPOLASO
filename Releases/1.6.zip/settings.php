<?php
	//MYSQL DATEN
	define("host","",true);
	define("password","",true);
	define("user","",true);
	define("database","",true);
	define("table","",true);

	//ANDERES
	define("name","NAME DER INSTALATION",true);
	define("spruch","MOTTO",true);
	define("url","",true);//freilassen wenn im rootverzeichniss sonst: /irgendwas/Beispiel für domain.beispiel/irgendwas/Beispiel
	define("mintime",ZEIT DIE EIN SCHÜLER min. GERANNT SEIN MUSS,true);	//in sekunden
	define("countdown",1000,true); // in sekunden*1000 ALSO in millisekunden
	define("minttime",0,true); //Mindest Anwesenheit  Zeit
	define("vermisttime",AB WANN MAN VERMISST WIRD,true); //in sekunden
?>
